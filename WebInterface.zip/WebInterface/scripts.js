document.getElementById('Unlock').disabled = true;
document.getElementById('Lock').disabled = true;


function changeSTS() {
  document.getElementById('mainSts').innerHTML = 'Connected ✔';
  document.getElementById('secondSts').innerHTML = 'Updated';
  document.getElementById('secondSts').style.color = 'green';
    if (document.getElementById('mainSts').innerHTML == 'Connected ✔') {
      document.getElementById('Unlock').disabled = false;
      document.getElementById('Lock').disabled = false;
    }
  }




function changeSTS2() {
  document.getElementById('secondSts').innerHTML = 'unlocked';
  document.getElementById('secondSts').style.color = 'blue';
}

function changeSTS3() {
  document.getElementById('secondSts').innerHTML = 'locked';
  document.getElementById('secondSts').style.color = 'red';
}



function closeForm() {
  document.getElementById("auth").style.display = "none";
}